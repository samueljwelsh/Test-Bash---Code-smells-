package search;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.junit.Test;
import pages.SearchPage;

import static org.junit.Assert.assertTrue;

public class SearchTests {

	@Test
	public void testSearchForTitle() {

		System.setProperty("webdriver.chrome.driver", "resources/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("INSERT FILE URL TO WEBSITE index.html FILE");

		String title = "Java For Testers";

		//Search for book
		SearchPage searchPage = new SearchPage(driver);
		boolean isBookVisible = searchPage.search(title);

		assertTrue("book does not exist: " + title, isBookVisible);

		driver.quit();
	}

	@Test
	public void testSearchForAuthor() {

		System.setProperty("webdriver.chrome.driver", "resources/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("INSERT FILE URL TO WEBSITE index.html FILE");

		String title = "Agile Testing";

		//Search for book
		SearchPage searchPage = new SearchPage(driver);
		boolean isBookVisible = searchPage.search("Lisa Crispin");

		assertTrue("book does not exist: " + title, isBookVisible);
		driver.quit();
	}
}
