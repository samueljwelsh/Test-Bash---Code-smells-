package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchPage {

	private WebDriver driver;
	private WebDriverWait wait;

	private By searchBar = By.id("searchBar");
	private By visibleBooks = By.xpath("//li[not(contains(@class, 'ui-screen-hidden'))]");
	private By hiddenBooks = By.xpath("//li[contains(@class, 'ui-screen-hidden')]");

	public SearchPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 5);
	}

	public void clear() {
		driver.findElement(searchBar).clear();
		wait.until(ExpectedConditions.numberOfElementsToBe(hiddenBooks, 0));
	}

	public void search(String title) {
		search(title, false);
	}

	public void search(String title, boolean ignoreIfNoFilter) {
		clear();
		driver.findElement(searchBar).sendKeys(title);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(hiddenBooks));
		}
		catch (NoSuchElementException e) {
			if(!ignoreIfNoFilter){
				throw e;
			}
		}
	}

	public boolean isBookVisible(String title){

		List<WebElement> books = driver.findElements(visibleBooks);
		for(WebElement book : books) {
			String id = book.getAttribute("id");
			String titleId = id + "_title";

			String bookTitle = book.findElement(By.id(titleId)).getText();

			if (title.equalsIgnoreCase(bookTitle)) {
				return true;
			}
		}

		return false;
	}

}
