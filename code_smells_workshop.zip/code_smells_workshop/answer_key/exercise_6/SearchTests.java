package search;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.junit.Test;
import pages.SearchPage;

import static org.junit.Assert.assertTrue;

public class SearchTests {

    private static WebDriver driver;
    private static SearchPage searchPage;

    @BeforeClass
    public static void setUp() {
        System.setProperty("webdriver.chrome.driver", "resources/chromedriver");
        driver = new ChromeDriver();
        driver.get("INSERT FILE URL TO WEBSITE index.html FILE");
        searchPage = new SearchPage(driver);
    }

    @AfterClass
    public static void tearDown() {
        driver.quit();
    }

    @Test
    public void testSearchForTitle() {
        String title = "Java For Testers";
        searchPage.search(title);
        assertTrue("book does not exist: " + title, searchPage.isBookVisible(title));
    }

    @Test
    public void testSearchForAuthor() {
        String title = "Agile Testing";
        searchPage.search("Lisa Crispin");
        assertTrue("book does not exist: " + title, searchPage.isBookVisible(title));
    }
}
