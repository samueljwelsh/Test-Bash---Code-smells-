package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import static org.junit.Assert.fail;

public class SearchPage {

	WebDriver driver;
	By searchBar = By.id("searchBar");
	By visibleBooks = By.xpath("//li[not(contains(@class, 'ui-screen-hidden'))]");

	public SearchPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clear() {
		driver.findElement(By.id("searchBar")).clear();
		try{
			Thread.sleep(5);
		}catch(InterruptedException e){
			fail(e.getMessage());
		}
	}

	public void search(String title) {

		clear();
		driver.findElement(By.id("searchBar")).sendKeys(title);
		try{
			Thread.sleep(5);
		}catch(InterruptedException e){
			fail(e.getMessage());
		}
	}

	public boolean isBookVisible(String title){
		boolean isBookVisible = false;

		List<WebElement> books = driver.findElements(visibleBooks);
		for(WebElement book : books) {
			String id = book.getAttribute("id");
			String titleId = id + "_title";

			String bookTitle = book.findElement(By.id(titleId)).getText();

			if (title.equalsIgnoreCase(bookTitle)) {
				isBookVisible = true;
				assertTrue("book does not exist: " + title, isBookVisible);
				break;
			}
		}

		if(!isBookVisible) {
			assertTrue("book does not exist: " + title, isBookVisible);
		}

		return isBookVisible;
	}

}
