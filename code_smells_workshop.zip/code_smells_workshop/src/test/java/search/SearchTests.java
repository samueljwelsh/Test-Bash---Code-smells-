package search;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;

public class SearchTests {

    @Test
    public void testSearchForTitle() {

        System.setProperty("webdriver.chrome.driver", "resources/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("INSERT FILE URL TO WEBSITE index.html FILE");

        String title = "Java For Testers";

        //Search for book
        driver.findElement(By.id("searchBar")).clear();
        try{
            Thread.sleep(5);
        }catch(InterruptedException e){
            fail(e.getMessage());
        }

        driver.findElement(By.id("searchBar")).sendKeys(title);
        try{
            Thread.sleep(5);
        }catch(InterruptedException e){
            fail(e.getMessage());
        }

        boolean isBookVisible = false;

        List<WebElement> books = driver.findElements(By.xpath("//*[@id='pid5']"));
        for(WebElement book : books) {
            String id = book.getAttribute("id");
            String titleId = id + "_title";

            String bookTitle = book.findElement(By.id(titleId)).getText();

            if (title.equalsIgnoreCase(bookTitle)) {
                isBookVisible = true;
                assertTrue("book does not exist: " + title, isBookVisible);
                break;
            }
        }

        if(!isBookVisible) {
            assertTrue("book does not exist: " + title, isBookVisible);
        }

        driver.quit();
    }

    @Test
    public void testSearchForAuthor() {

        System.setProperty("webdriver.chrome.driver", "resources/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("INSERT FILE URL TO WEBSITE index.html FILE");

        String title = "Agile Testing";

        //Search for book
        driver.findElement(By.id("searchBar")).clear();
        try{
            Thread.sleep(2);
        }catch(InterruptedException e){
            fail(e.getMessage());
        }

        driver.findElement(By.id("searchBar")).sendKeys("Lisa Crispin");
        try{
            Thread.sleep(2);
        }catch(InterruptedException e){
            fail(e.getMessage());
        }

        boolean isBookVisible = false;

        List<WebElement> books = driver.findElements(By.xpath("//*[@id='pid3']"));
        for(WebElement book : books) {
            String id = book.getAttribute("id");
            String titleId = id + "_title";

            String bookTitle = book.findElement(By.id(titleId)).getText();

            if (title.equalsIgnoreCase(bookTitle)) {
                isBookVisible = true;
                assertTrue("book does not exist: " + title, isBookVisible);
                break;
            }
        }

        if(!isBookVisible) {
            assertTrue("book does not exist: " + title, isBookVisible);
        }

        driver.quit();
    }
}